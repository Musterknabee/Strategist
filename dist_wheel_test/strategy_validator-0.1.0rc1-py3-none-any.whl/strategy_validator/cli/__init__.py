"""Operator CLI entrypoints."""
